# SJS_SCRIPTS
STRIKE COOK GROUP EXCLUSIVE SJS SCRIPTS
This ONLY runs on python 2.7
Firstly, use pip install requests and pip install names

then cd into the folder where you downloaded the script.

In the python files, make sure to enter your email, city, and most importantly your 2Captcha api key.


Youtube video guide - https://www.youtube.com/watch?v=Ss7al4m4cd0
